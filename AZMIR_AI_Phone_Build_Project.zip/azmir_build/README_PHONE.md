# AZMIR AI — ফোন দিয়েই APK বানানোর পথ

এই project-এ GitHub Actions workflow যোগ করা হয়েছে। PC ছাড়াই GitHub-এর মাধ্যমে cloud build চালিয়ে APK artifact পাওয়া যাবে।

## কী করবে
1. পুরো project GitHub repository-তে upload করো।
2. GitHub-এর **Actions** tab খুলে **Build AZMIR AI APK** workflow চালাও (বা main branch-এ push হলে এটি চলবে)।
3. Build শেষ হলে workflow-এর **Artifacts** অংশ থেকে `AZMIR-AI-debug-apk` download করো।
4. Android ফোনে APK install করো।

## বর্তমান app
এটি এখনো live-market signal engine নয়। Fake signal বা guaranteed profit দেখায় না। পরের ধাপে backend/API analysis যুক্ত করতে হবে।
