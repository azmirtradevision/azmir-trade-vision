package com.azmir.ai;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    TextView status, result, details;
    Button analyze;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        Spinner asset = findViewById(R.id.asset);
        Spinner expiry = findViewById(R.id.expiry);
        status = findViewById(R.id.status);
        result = findViewById(R.id.result);
        details = findViewById(R.id.details);
        analyze = findViewById(R.id.analyze);

        String[] assets = {"EUR/USD OTC","GBP/USD OTC","USD/JPY OTC","CAD/CHF OTC"};
        String[] expiries = {"5 seconds","10 seconds"};
        asset.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, assets));
        expiry.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, expiries));

        analyze.setOnClickListener(v -> {
            analyze.setEnabled(false);
            result.setText("ANALYZING…");
            result.setTextColor(Color.WHITE);
            details.setText("Preparing candle / price-action analysis…");
            status.setText("Market data connection is not configured.");
            new Handler().postDelayed(() -> {
                analyze.setEnabled(true);
                result.setText("NO TRADE");
                result.setTextColor(Color.LTGRAY);
                details.setText("This build intentionally does not invent a signal without verified live data.");
                status.setText("Analysis stopped safely.");
            }, 1400);
        });
    }
}
