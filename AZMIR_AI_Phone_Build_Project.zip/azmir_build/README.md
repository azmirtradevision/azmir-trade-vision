# AZMIR AI — Android App Foundation

This is the first Android Studio project for AZMIR AI.

It contains:
- AZMIR AI branded Android UI
- OTC asset and expiry selectors
- Analyze button and analysis-state animation
- Safe NO TRADE fallback
- No auto-trading
- No fake live market data

Important:
This project is intentionally not presented as a guaranteed-profit or 100%-accurate trading bot.
Before live signals can be enabled, a verified market-data source and a tested analysis engine must be connected.
